<?php
error_reporting(E_ALL);
ini_set('display_errors', 'On');

define('DATABASE_NAME', 'mcuthail_mcu');
define('DATABASE_USER', 'mcuthail_mcu');
define('DATABASE_PASS', 'q1w2e3');
define('DATABASE_HOST', 'localhost');
?>