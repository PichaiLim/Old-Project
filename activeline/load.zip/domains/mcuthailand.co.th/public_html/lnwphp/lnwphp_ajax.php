<?php include ('lnwphp.php');
echo lnwphp::get_requested_instance();
