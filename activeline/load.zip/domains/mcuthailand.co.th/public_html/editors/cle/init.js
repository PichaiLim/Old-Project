jQuery(".xcrud-texteditor").cleditor({
    useCSS: true
});
Xcrud.save_editor_content = function(){
    // some code
}