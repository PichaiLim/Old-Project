CKEDITOR.config.allowedContent = true;
CKEDITOR.replaceAll('editor-instance'); // important