tinyMCE.init({
	mode: "textareas", // important
	editor_selector: "editor-instance",	// important
    
	valid_elements: '*[*]',
	height: "250"
});